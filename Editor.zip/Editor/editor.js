window.onload = function ()
{
    let editor = frme.document;
    editor.designMode = "on";
    console.log("Hello World");
    let drop = document.querySelectorAll('select#dropdown-one > option');
    //console.log(drop[1].value);
    for(let i=0;i<drop.length;i++)
    {
        drop[i].style.fontFamily = drop[i].value;
    }

    let bold = document.getElementById("bold");
    bold.addEventListener("click",()=>{
        editor.execCommand("Bold",false,null);
        
    });

    let italic = document.getElementById("italic");
    italic.addEventListener("click",()=>{
        editor.execCommand("Italic",false,null);
    });

    let underline = document.getElementById("underline");
    underline.addEventListener("click",()=>{
        editor.execCommand("Underline",false,null);
    });

    let superscript = document.getElementById("superscript");
    superscript.addEventListener("click",()=>{
        editor.execCommand("Superscript",false,null);
    });

    let subscript = document.getElementById("subscript");
    subscript.addEventListener("click",()=>{
        editor.execCommand("Subscript",false,null);
    });

    let strikethrough = document.getElementById("strikethrough");
    strikethrough.addEventListener("click",()=>{
        editor.execCommand("Strikethrough",false,null);
    });

    let list = document.getElementById("list");
    list.addEventListener("click",()=>{
        editor.execCommand("InsertOrderedList", false, "newOL" + Math.round(Math.random()*1000));
    });

    let unlist = document.getElementById("unlist");
    unlist.addEventListener("click",()=>{
        editor.execCommand("InsertUnorderedList", false, "new" + Math.round(Math.random()*1000));
    });

    let color = document.getElementById("font-color");
    color.addEventListener("change",(el)=>{
        editor.execCommand("ForeColor", false, el.target.value);
    });

    let bgcolor = document.getElementById("background-color");
    bgcolor.addEventListener("change",(el)=>{
        editor.execCommand("BackColor", false, el.target.value);
    });

    let dropdownone = document.getElementById("dropdown-one");
    dropdownone.addEventListener("change",(el)=>{
        editor.execCommand("FontName", false, el.target.value);
    });

    let dropdowntwo = document.getElementById("dropdown-two");
    dropdowntwo.addEventListener("change",(el)=>{
        editor.execCommand("FontSize", false, el.target.value);
    });

    let link = document.getElementById("link");
    link.addEventListener("click",()=>{
        let url = prompt("Enter a link: ","https://");
        editor.execCommand("CreateLink", false, url);
    });

    let unlink = document.getElementById("unlink");
    unlink.addEventListener("click",()=>{
        editor.execCommand("UnLink",false,null);
    });

    let undo = document.getElementById("undo");
    undo.addEventListener("click",()=>{
        editor.execCommand("undo",false,null);
    });

    let redo = document.getElementById("redo");
    redo.addEventListener("click",()=>{
        editor.execCommand("redo",false,null);
    });
    



}